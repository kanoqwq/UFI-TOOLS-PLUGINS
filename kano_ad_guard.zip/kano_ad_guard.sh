#!/system/bin/sh
kano_path="/data/kano_ad_guard"
nohup "$kano_path/AdGuardHome" > /dev/null 2>&1 &