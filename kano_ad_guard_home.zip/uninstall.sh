MODPATH="/data/agh"
AGH_DIR="$MODPATH/agh"
$AGH_DIR/scripts/tool.sh stop    # 停止
echo "ADGuard停止成功"
sleep 1
[ -d "$MODPATH" ] && rm -rf "$MODPATH"
echo "ADGuard卸载成功"