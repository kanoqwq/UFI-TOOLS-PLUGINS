MODPATH="/data/agh"
AGH_DIR="$MODPATH/agh"

start() {
  $AGH_DIR/scripts/tool.sh start   # 启动
  echo "ADGuard启动成功"
}

stop() {
  $AGH_DIR/scripts/tool.sh stop    # 停止
  echo "ADGuard停止成功"
}

toggle() {
  $AGH_DIR/scripts/tool.sh toggle  # 启动或停止
  echo "ADGuard重启成功"
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  toggle)
    toggle
    ;;
esac