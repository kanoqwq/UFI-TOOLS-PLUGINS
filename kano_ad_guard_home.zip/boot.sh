MODPATH="/data/agh"
AGH_DIR="$MODPATH/agh"
PID_FILE="$AGH_DIR/bin/agh.pid"

$AGH_DIR/scripts/tool.sh start
