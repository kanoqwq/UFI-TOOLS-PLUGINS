#!/system/bin/sh

WEB_PASSWORD="Wa@9w+YWRtaW4="
WIFI_CHIP=chip2

STATE_READY=0
DEVICE_PATH="/sys/bus/usb/devices"
STATE_PATH="/sys/class/android_usb/android0/state"
LAST_USB_STATE=""
LAST_HAS_LAN=0


log() {
    TS="[$(date '+%Y-%m-%d %H:%M:%S')]"
    LOG_DIR="/data/kano_auto_wifi/logs"
	mkdir -p "$LOG_DIR"
	LOG_FILE="$LOG_DIR/auto_wifi_$(date +%F).log"

	# 清理 3 天前的日志
	find "$LOG_DIR" -name "auto_wifi_*.log" -type f -mtime +2 -delete
    echo "$TS $*" | tee -a "$LOG_FILE"
}

log "[守护] 启动 USB / OTG 状态监听服务（优先检测 LAN 网卡）..."

chmod 755 /data/kano_auto_wifi/zreq

while true; do
    # ✅ 检查 LAN 网卡
    HAS_LAN=0
    for DEV in $(ls "$DEVICE_PATH" | grep -E '^[0-9]+-[0-9]+$'); do
        PRODUCT_FILE="$DEVICE_PATH/$DEV/product"
        if [ -f "$PRODUCT_FILE" ]; then
            PRODUCT=$(cat "$PRODUCT_FILE" 2>/dev/null)
            if echo "$PRODUCT" | grep -qi "LAN"; then
                HAS_LAN=1
                break
            fi
        fi
    done

    if [ "$HAS_LAN" != "$LAST_HAS_LAN" ]; then
        log "[LAN变更] 是否插入 LAN 网卡: $HAS_LAN"

        if [ "$STATE_READY" -eq 1 ]; then
            if [ "$HAS_LAN" -eq 1 ]; then
                log "[LAN插入] 关闭 WiFi"
                /data/kano_auto_wifi/zreq --method POST -body "goformId=switchWiFiModule&SwitchOption=0" -pwd "$WEB_PASSWORD"
            else
                log "[LAN拔出] 恢复 WiFi"
                /data/kano_auto_wifi/zreq --method POST -body "goformId=switchWiFiChip&ChipEnum=$WIFI_CHIP" -pwd "$WEB_PASSWORD"
            fi
        else
            log "[首次启动] 当前 LAN 状态: $HAS_LAN，跳过首次动作"
            STATE_READY=1
        fi

        LAST_HAS_LAN=$HAS_LAN
    fi

    # ✅ USB共享网络判断（只有在未插入 LAN 时才判断）
    if [ "$HAS_LAN" -eq 0 ]; then
        if [ -f "$STATE_PATH" ]; then
            CURRENT_USB_STATE=$(cat "$STATE_PATH")
        else
            CURRENT_USB_STATE=""
        fi

        if [ "$CURRENT_USB_STATE" != "$LAST_USB_STATE" ]; then
            log "[USB状态变更] 当前 USB 状态: $CURRENT_USB_STATE"

            if [ "$STATE_READY" -eq 1 ]; then
                case "$CURRENT_USB_STATE" in
                    CONNECTED|CONFIGURED)
                        log "[USB共享网络启用] 关闭 WiFi"
                        /data/kano_auto_wifi/zreq --method POST -body "goformId=switchWiFiModule&SwitchOption=0" -pwd "$WEB_PASSWORD"
                        ;;
                    DISCONNECTED)
                        log "[USB共享网络关闭] 恢复 WiFi"
                        /data/kano_auto_wifi/zreq --method POST -body "goformId=switchWiFiChip&ChipEnum=$WIFI_CHIP" -pwd "$WEB_PASSWORD"
                        ;;
                esac
            else
                log "[首次启动] 当前 USB 状态: $CURRENT_USB_STATE，跳过首次动作"
                STATE_READY=1
            fi

            LAST_USB_STATE="$CURRENT_USB_STATE"
        fi
    fi

    sleep 1
done
