#!/system/bin/sh
Module_dir="/data/kano_npc"
sdcard_dir="/sdcard"

start() {
    if ! (ps -ef | grep -- 'npc -config' | grep -vE 'grep') > /dev/null ; then
        nohup $Module_dir/npc -config $Module_dir/npc.ini > $sdcard_dir/NPC_LOG.txt 2>&1 &
        
        echo "NPC已启动"
    else
        echo "NPC正在运行中，不执行启动命令"
    fi
}

stop() {
    if (ps -ef | grep -- 'npc -config' | grep -vE 'grep') > /dev/null ; then
        pid=$(pgrep -f 'npc -config')
        kill -15 $pid

        echo "NPC已关闭"
        echo "NPC已关闭" > $sdcard_dir/NPC_LOG.txt
    else
        echo "NPC未在运行，不执行停止命令" 
        echo "NPC未在运行，不执行停止命令" > $sdcard_dir/NPC_LOG.txt
    fi
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    *)
        echo "只能使用start|stop两个参数控制NPC启动或停止"
        echo "只能使用start|stop两个参数控制NPC启动或停止" > $sdcard_dir/NPC_LOG.txt
        exit 1
        ;;
esac
