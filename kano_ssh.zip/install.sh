#!/system/bin/sh

MODPATH="/data/ssh"

# 通用权限
chmod 0755 "$MODPATH"
chmod 755 "$MODPATH/common/opensshd.init"

# 配置文件
chmod 600 "$MODPATH/sshd_config"

# shell 用户
chown shell:shell "$MODPATH/shell" "$MODPATH/shell/.ssh"
chmod 700 "$MODPATH/shell" "$MODPATH/shell/.ssh"
chown shell:shell "$MODPATH/shell/.ssh/authorized_keys"
chmod 600 "$MODPATH/shell/.ssh/authorized_keys"

# root 用户
chown root:root "$MODPATH/root" "$MODPATH/root/.ssh"
chmod 700 "$MODPATH/root" "$MODPATH/root/.ssh"
chown root:root "$MODPATH/root/.ssh/authorized_keys"
chmod 600 "$MODPATH/root/.ssh/authorized_keys"

#移动key
mv "$MODPATH/keys/kano_id_ed25519" "/sdcard/ufi_ssh_key_id_ed25519"