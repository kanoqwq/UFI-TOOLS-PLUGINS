(() => {
    const btn_enabled = document.createElement('button')
    btn_enabled.textContent = "安装SSH"
    btn_enabled.onclick = async () => {
        createToast("下载openSSH...")
        const res1 = await runShellWithRoot(`
/data/data/com.minikano.f50_sms/files/curl -L https://pan.kanokano.cn/d/UFI-TOOLS/kano_ssh.zip -o /data/kano_ssh.zip
`)
        if (!res1.success) return createToast("下载openSSH依赖失败!", 'red')

        createToast("解压openSSH文件...")
        const res2 = await runShellWithRoot(`
cd /data/
mkdir -p ssh
unzip kano_ssh.zip -d /data/ssh/
`)
        if (!res2.success) return createToast("解压openSSH文件出错!", 'red')

        createToast("检查openSSH依赖文件...")
        const res3 = await runShellWithRoot(`
ls /data/ssh
`)
        if (!res3.success || !res3.content.includes('install.sh')) return createToast("检查openSSH依赖文件失败!", 'red')

        createToast("修改openSSH目录权限...")
        const res4 = await runShellWithRoot(`
sh /data/ssh/install.sh
`)
        if (!res4.success) return createToast("修改openSSH目录权限失败!", 'red')

        createToast("设置SSHD自启动...")
        const res5 = await runShellWithRoot(`
grep -qxF '/data/ssh/common/opensshd.init start' /sdcard/ufi_tools_boot.sh || echo '/data/ssh/common/opensshd.init start' >> /sdcard/ufi_tools_boot.sh
`)
        if (!res5.success) return createToast("设置SSHD自启动失败!", 'red')

        createToast("启动SSHD...")
        const res6 = await runShellWithRoot(`
/data/ssh/common/opensshd.init start
`)
        if (!res6.success) return createToast("启动SSHD失败!", 'red')

        createToast(`<div style="width:300px;text-align:center">
设置SSHD成功！<br/>登录公钥key在内部存储/ufi_ssh_key_id_ed25519<br/>注：处于安全考虑，请务必更换为自己的公钥
</div>
`, '', 10000)
    }
    const btn_disabled = document.createElement('button')
    btn_disabled.textContent = "卸载SSH"
    btn_disabled.onclick = async () => {
        const res = await runShellWithRoot(`
            /data/ssh/common/opensshd.init stop
            rm -rf /data/ssh
            sed -i '/^\/data\/ssh\/common\/opensshd.init start$/d' /sdcard/ufi_tools_boot.sh
        `)
        if (!res.success) return createToast("卸载失败！", 'red')
        createToast("卸载成功！", 'red')
    }
    collapseBtn_menu.nextElementSibling.querySelector('.collapse_box').appendChild(btn_enabled)
    collapseBtn_menu.nextElementSibling.querySelector('.collapse_box').appendChild(btn_disabled)
})()

