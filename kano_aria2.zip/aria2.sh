#!/system/bin/sh

ARIA2_BIN="/data/aria2/aria2c"
ARIA2_LOG="/data/aria2/aria2.log"
ARIA2_SESSION="/data/aria2/aria2.session"
PID_FILE="/data/aria2/aria2.pid"
DOWNLOAD_DIR="/sdcard/"
RPC_SECRET_FILE="/sdcard/aria2_pwd"

start() {
    mkdir -p /data/data/com.minikano.f50_sms/files/uploads 
    cp /data/aria2/index.html /data/data/com.minikano.f50_sms/files/uploads/aria2.html
    if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
        echo "Aria2 is already running with PID $(cat $PID_FILE)"
        exit 0
    fi

    if [ ! -f "$RPC_SECRET_FILE" ]; then
        echo "Error: RPC secret file not found at $RPC_SECRET_FILE"
        exit 1
    fi

    RPC_SECRET=$(cat "$RPC_SECRET_FILE" | tr -d '\r\n')
    echo "RPC SECRET: $RPC_SECRET"
    echo "Starting Aria2..."
    "$ARIA2_BIN" \
        --dir="$DOWNLOAD_DIR" \
        --disable-ipv6=true \
        --enable-rpc=true \
        --rpc-allow-origin-all=true \
        --rpc-listen-all=true \
        --rpc-listen-port=6800 \
        --rpc-secret=$RPC_SECRET \
        --continue=true \
        --input-file="$ARIA2_SESSION" \
        --save-session="$ARIA2_SESSION" \
        --max-concurrent-downloads=5 \
        --max-connection-per-server=16 \
        --log="$ARIA2_LOG" \
        --check-certificate=false >/dev/null 2>&1 &

    echo $! > "$PID_FILE"
    echo "Aria2 started with PID $(cat $PID_FILE)"
}

stop() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 $PID 2>/dev/null; then
            echo "Stopping Aria2 (PID $PID)..."
            kill $PID
            rm -f "$PID_FILE"
            echo "Aria2 stopped."
        else
            echo "Stale PID file found but process not running. Cleaning up..."
            rm -f "$PID_FILE"
        fi
    else
        echo "Aria2 is not running."
    fi
}

restart() {
    stop
    sleep 1
    start
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        restart
        ;;
    *)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
        ;;
esac