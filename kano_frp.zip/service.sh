#!/system/bin/sh
Module_dir="/data/kano_frp"
sdcard_dir="/sdcard"

start() {
    if ! (ps -ef | grep -- 'frpc -c' | grep -vE 'grep') > /dev/null ; then
        nohup $Module_dir/frpc -c $Module_dir/frpc.ini > $sdcard_dir/FRPC_LOG.txt 2>&1 &
        
        echo "FRPC已启动"
    else
        echo "FRPC正在运行中，不执行启动命令"
    fi
}

stop() {
    if (ps -ef | grep -- 'frpc -c' | grep -vE 'grep') > /dev/null ; then
        pid=$(pgrep -f 'frpc -c')
        kill -15 $pid

        echo "FRPC已关闭"
        echo "FRPC已关闭" > $sdcard_dir/FRPC_LOG.txt
    else
        echo "FRPC未在运行，不执行停止命令" 
        echo "FRPC未在运行，不执行停止命令" > $sdcard_dir/FRPC_LOG.txt
    fi
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    *)
        echo "只能使用start|stop两个参数控制FRPC启动或停止"
        echo "只能使用start|stop两个参数控制FRPC启动或停止" > $sdcard_dir/FRPC_LOG.txt
        exit 1
        ;;
esac
